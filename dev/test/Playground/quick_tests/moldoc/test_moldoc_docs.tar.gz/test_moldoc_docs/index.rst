=============================================================
test moldoc
=============================================================

This is the ``index.rst`` file, here moldoc works well:

.. moldoc::

    import moldoc.molecule as molecule
    import stk

    bb1 = stk.BuildingBlock('NCCCN')

    moldoc_display_molecule = molecule.Molecule(
        atoms=(
            molecule.Atom(
                atomic_number=atom.get_atomic_number(),
                position=position,
            ) for atom, position in zip(
                bb1.get_atoms(),
                bb1.get_position_matrix(),
            )
        ),
        bonds=(
            molecule.Bond(
                atom1_id=bond.get_atom1().get_id(),
                atom2_id=bond.get_atom2().get_id(),
                order=bond.get_order(),
            ) for bond in bb1.get_bonds()
        ),
    )

It also works well for .rst files in the same directory (``./dirdepth0_works.rst``) and one directory deep (``./doc_files/dirdepth1_works.rst``). However, it does not work if the .rst file is located two directories deep (``./doc_files/testdir/dirdepth1_works.rst``):

.. toctree::
   :maxdepth: 2
   :caption: test n directories deep

   dirdepth0_works
   doc_files/dirdepth1_works
   doc_files/testdir/dirdepth2_doesnt_work
