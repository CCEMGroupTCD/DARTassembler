Dirdepth0: works
==============================================

This works, because this file is in the same directory as index.rst under ``.dirdepth0_works.rst``.

.. moldoc::

    import moldoc.molecule as molecule
    import stk

    bb1 = stk.BuildingBlock('NCCCN')

    moldoc_display_molecule = molecule.Molecule(
        atoms=(
            molecule.Atom(
                atomic_number=atom.get_atomic_number(),
                position=position,
            ) for atom, position in zip(
                bb1.get_atoms(),
                bb1.get_position_matrix(),
            )
        ),
        bonds=(
            molecule.Bond(
                atom1_id=bond.get_atom1().get_id(),
                atom2_id=bond.get_atom2().get_id(),
                order=bond.get_order(),
            ) for bond in bb1.get_bonds()
        ),
    )

Yep it works!
